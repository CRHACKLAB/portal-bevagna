# README

## verisone aframe

si usa la versione 1.4.0 perché nella successiva (1.5.0) hanno modificato il modo di gestione delle luci e quindi non funziona correttamente l'autoReparent.

## Ordine

1. a-sky 
2. a-entity (portal)
3. a-box (o tutto quello che deve andare all'interno del portale)


## misure portale

- Diameter 3
- Hole size 1
- color #371C0B / rgb(55, 28, 11)

# portal-bevagna
# portal-bevagna
